
void simple()
{}
